# monospacer
Set brave browser web content font-family to monospace

## Getting started

- Clone this repository
- Open `brave://extensions/` and enable developer mode
- `Load unpacked` from cloned directory
- ![image](https://user-images.githubusercontent.com/11949221/120403564-cebd2380-c31a-11eb-9f7d-ee1be75c978c.png)


## Scripts
TL;DR
```bash
make
```
