# monospacer
Set brave browser web content font-family to monospace
